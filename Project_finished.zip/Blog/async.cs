﻿namespace Blog
{
    internal class async
    {
    }
}
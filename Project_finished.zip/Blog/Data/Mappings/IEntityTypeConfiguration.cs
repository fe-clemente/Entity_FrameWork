﻿namespace Blog.Data.Mappings

{
    public interface IEntityTypeConfiguration
    {
    }
}